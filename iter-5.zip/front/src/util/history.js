
import { createBrowserHistory } from 'history';

export const history = createBrowserHistory();
// import { useHistory } from "react-router-dom";
//
// export const history=useHistory();