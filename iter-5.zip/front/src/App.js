import React from 'react';
import './App.css';
import BasicRoute from "./Router";


function App() {
  return (
    <BasicRoute />
  );
}

export default App;
